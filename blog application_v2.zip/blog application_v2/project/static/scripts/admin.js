function approveRestaurent(identifier){
  var restaurantId = $(identifier).data("id");
  $("#restaurantId").val(restaurantId);
}